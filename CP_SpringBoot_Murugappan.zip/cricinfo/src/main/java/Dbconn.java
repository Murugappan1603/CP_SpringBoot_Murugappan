import java.sql.*;
public class Dbconn {
	Connection con;
	Statement stmt;
	PreparedStatement pst;
	public Dbconn(){

		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","Anandh1603");  
			
			stmt=con.createStatement(); 
			
		}catch(Exception e){
			System.out.println(e);
		}  
	}
	public int insert(String name,String uname,String pswd,int ph) throws SQLException {
		
		String str="insert into reg(name,username,password,phone) values('"+name+"','"+uname+"','"+pswd+"',"+ph+")";
		System.out.println(name+uname+pswd+ph);
		stmt.executeUpdate(str);
		System.out.println(name+uname+pswd+ph);
		return 1;
	}
	public int login(String uname,String pswd) throws SQLException {
		String str = "select * from reg where username='"+uname+"' and password='"+pswd+"'";
		ResultSet rs = stmt.executeQuery(str);
		if(rs.next()) 
			return 1;
		
		else
			return 0;
	}
	public void delete(int id) throws SQLException {
		String str="delete from reg where id="+id;
		stmt.executeUpdate(str);
	}
	public ResultSet display() throws SQLException {
		String str="select * from reg";
		ResultSet rs=stmt.executeQuery(str);
		return rs;
	}

	

	}
